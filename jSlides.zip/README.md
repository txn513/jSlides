jSlides
========

A jQuery Plugin to make css3 sliders

Documentation: 