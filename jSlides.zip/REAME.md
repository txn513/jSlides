jSlides
========

A jQuery Plugin to make css3 slides

Documentation: 